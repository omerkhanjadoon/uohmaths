var myname="RESEARCH";
var red=[0,100,63];
var green=[40,120,60];
var blue=[75,100,40];
var yellow=[196,77,55];
var orange=[280,50,60];

var mycolors=[red,blue,green,yellow,orange];



drawName(myname,mycolors);
bubbleShape="circle";
bounceBubbles();